#include "StdAfx.h"
#include "Pila.h"
#include <iostream>
#define MAX 5
using namespace std;

Pila::Pila(void)
{ 
  Tope=-1;
}


Pila::~Pila(void)
{
}
int Pila::Get_tope()
{
	return Tope;
}
int Pila::Get_Pila(int posicion)
{
	return pila[posicion];
}

/*void Pila::Set_Pila(int posicion,int elemento)
{
	pila[posicion]=elemento;
}

void Pila::Set_tope(int tope)
{
	Tope=tope;
}*/
bool Pila::PilaVacia()
{if(Get_tope()==-1)
{return true;
}else{return false;}
}
bool Pila::Desapilar()
{if(PilaVacia())
{return false;
}
else
{Tope=Get_tope()-1;
 return true;
}
}
bool Pila::pilallena()
{if(Get_tope()==(MAX-1))
 {return true;
 }
 else{return false;}
}
bool Pila::Apilar(int elemento)
{
  if(pilallena())
  {
  return false; 
  }
  else
  {Tope=Get_tope()+1;
  pila[Get_tope()]=elemento;
  return true;
  }
}

