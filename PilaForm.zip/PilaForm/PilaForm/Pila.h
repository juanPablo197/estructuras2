#pragma once
#define MAX 5
class Pila
{int pila[MAX];
 int Tope;
public:
	Pila(void);
	~Pila(void);
	int Get_Pila(int posicion);
	int Get_tope();
	//void Set_Pila(int posicion,int elemento);
	//void Set_tope(int tope);
	bool Apilar(int elemento);
	bool PilaVacia();
	bool Desapilar();
	bool pilallena();
	
};

