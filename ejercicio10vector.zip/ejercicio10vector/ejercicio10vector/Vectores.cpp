#include "StdAfx.h"
#include "Vectores.h"
#include <iostream>

#define MAX 100

using namespace std;

Vectores::Vectores(void)
{V[MAX]=0;
 A[MAX]=0;
 Z[MAX]=0;
 n=0;
 m=0;
 c=0;
}


Vectores::~Vectores(void)
{
}
void Vectores::Cargar(int v[],int a[],int n,int m)
{cout<<"Llenando el vector 1 con "<<n<<" elementos..."<<endl;
 for(int i=0;i<n;i++)
 {cout<<"V["<<i<<"]= ";
    cin>>v[i];
 }
 cout<<"Llenando el vector 2 con "<<m<<" elementos..."<<endl;
 for(int i=0;i<m;i++)
 {cout<<"A["<<i<<"]= ";
    cin>>A[i];
 }
}
void Vectores::Orednar(int v[],int a[],int n,int m)
{int aux;
 //para vector v
 for(int i=0;i<n-1;i++)
  {for(int k=i+1;k<n;k++)
   {if(v[i]>v[k])
    {aux=v[k];
     v[k]=v[i];
	 v[i]=aux;
    }
   } 
  }
 cout<<"Vector ordenado"<<endl;
 for(int i=0;i<n;i++)
 {cout<<"V["<<i<<"]= "<<v[i]<<endl;
 }
 //para vector a
 int bur;
 for(int i=0;i<m-1;i++)
  {for(int k=i+1;k<m;k++)
   {if(A[i]>A[k])
    {bur=A[k];
     A[k]=A[i];
	 A[i]=bur;
    }
   } 
  }
  cout<<"Vector ordenado"<<endl;
 for(int i=0;i<m;i++)
 {cout<<"A["<<i<<"]= "<<A[i]<<endl;
 }
}
void Vectores::Concatenar(int v[],int a[],int z[],int n,int m,int c)
{z[0]=v[0];
 z[1]=A[0];
 int cont=1;
 for(int i=2;i<c;i++)
 {if(i%2==0)
  {if((i-n)>=n)
   {z[i]=A[cont];
    cont++;
   }
   else
   {if(i%2==0)
    {z[i]=v[i/2];
    }  
   }
  }
  else
  {if(i%2!=0)
   {if((i-m)>=m)
    {z[i]=v[(i-1)/2];
    }
    else
	{if(i%2!=0)
     {z[i]=A[cont];
      cont++;}
    }
   }
  }
 }
}
void Vectores::Mostrar(int z[],int c)
{cout<<"\n mostrando vector concatenado"<<endl;
 for(int pos=0;pos<c;pos++)
 {cout<<"Z["<<pos<<"]= "<<z[pos]<<endl;
 }
}
