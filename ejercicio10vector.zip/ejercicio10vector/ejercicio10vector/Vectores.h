#pragma once
#define MAX 100
class Vectores
{private:
int V[MAX],A[MAX],Z[MAX],n,m,c;
public:
	Vectores(void);
	~Vectores(void);
	void Cargar(int v[],int a[],int n,int m);
	void Orednar(int v[],int a[],int n,int m);
	void Concatenar(int v[],int a[],int z[],int n,int m,int c);
	void Mostrar(int z[],int c);
};

