// ejercicio10vector.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "Vectores.h"
#include <iostream>
#include "conio.h"
#define MAX 100

using namespace std;

void main()
{int V[MAX],A[MAX],Z[MAX],n,m,c;
 Vectores vector1;
 do {
		cout<<"Ingrese el tamanio del vector 1 : ";
		cin>>n;
	} while ((n>MAX) || (n<=0));
 do {
		cout<<"Ingrese el tamanio del vector 2 : ";
		cin>>m;
	} while ((m>MAX) || (m<=0));
 c=n+m;
 vector1.Cargar(V,A,n,m);
 vector1.Orednar(V,A,n,m);
 vector1.Concatenar(V,A,Z,n,m,c);
 vector1.Mostrar(Z,c);
getch();	
}

