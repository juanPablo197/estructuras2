#include "StdAfx.h"
#include "Eliminados.h"
#include <iostream>
#define MAX 100

using namespace std;

Eliminados::Eliminados(void)
{V[MAX]=0;
 tam=0;
}


Eliminados::~Eliminados(void)
{
}
void Eliminados::Cargar(int v[],int tam)
{for(int i=0;i<tam;i++)
 {do{cout<<"ingrese numeros distintos a 0"<<endl;
	cout<<"V["<<i<<"]= ";
	cin>>v[i];}while(v[i]==0);
 }
}
void Eliminados::Eliminar(int v[],int tam)
{int cont=0;
 for(int k=0,aux;k<tam-1;k++)//ordeno el vector para comparar los valores
    {for(int o=k+1;o<tam;o++)
       {if(v[k]>v[o])
         {aux= v[o];
          v[o]=v[k];
          v[k]=aux;
         }
        }
       }
 cout<<"VECTOR ORDENADO"<<endl;
 for(int i=0;i<tam;i++)
 {cout<<"V["<<i<<"]= "<<v[i]<<endl;
 }
 for(int pos=0;pos<tam;pos++)//elimino los numeros repetidos reemplazando con un 0
 {if(v[pos]==v[pos+1])
  {v[pos+1]=0;
   cont++;
  }
}
 cout<<"han sido eliminados "<<cont<<" numeros"<<endl;
for(int pos=0;pos<tam;pos++)
{if(v[pos]!=0)
 {cout<<"V["<<pos<<"]="<<v[pos]<<endl;
 }
 else
 {cout<<"V["<<pos<<"]= HA SIDO ELIMINADO"<<endl;
 }
}


}

