#pragma once
#define MAX 100
class Eliminados
{private:
int V[MAX],tam;
 public:
	Eliminados(void);
	~Eliminados(void);
	void Cargar(int v[],int tam);
	void Eliminar(int v[],int tam);
};

