// ejercicio12vector.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "conio.h"
#include "Eliminados.h"
#include <iostream>
#define MAX 100
using namespace std;

void main()
{int V[MAX],tam;
 Eliminados eliminar;
 do {cout<<"Ingrese el tamanio del vector: ";
	 cin>>tam;
	} while ((tam>MAX) || (tam<=0));
 eliminar.Cargar(V,tam);
 eliminar.Eliminar(V,tam);
 getch();
}

