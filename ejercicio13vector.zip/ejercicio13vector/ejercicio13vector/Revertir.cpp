#include "StdAfx.h"
#include "Revertir.h"
#include <iostream>
#define MAX 100

using namespace std;

Revertir::Revertir(void)
{Vec[MAX]=0;
 tam=0;
}


Revertir::~Revertir(void)
{
}
void Revertir::Cargar(int v[],int tam)
{for(int i=0;i<tam;i++)
 {cout<<"V["<<i<<"]= ";
    cin>>v[i];
 }
}
void Revertir::Revertido(int v[],int tam)
{int aux;
 for(int i=tam-1,k=0;k<(tam/2);i--,k++)
 {aux=v[k];
  v[k]=v[i];
  v[i]=aux;
 }
 cout<<"MOSTRANDO VECTOR INVERTIDO..."<<endl;
 for(int i=0;i<tam;i++)
 {cout<<"V["<<i<<"]= "<<v[i]<<endl;
 }
}
