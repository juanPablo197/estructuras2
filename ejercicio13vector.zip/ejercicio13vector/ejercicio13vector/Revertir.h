#pragma once
#define MAX 100
class Revertir
{private:
int Vec[MAX],tam;
public:
	Revertir(void);
	~Revertir(void);
	void Cargar(int v[],int tam);
	void Revertido(int v[],int tam);
};

