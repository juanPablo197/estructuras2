// ejercicio13vector.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "conio.h"
#include <iostream>
#include "Revertir.h"
#define MAX 100

using namespace std;

void main()
{int Vec[MAX],tam;
 Revertir reversa;
do {
		cout<<"Ingrese el tamanio del vector : ";
		cin>>tam;
	} while ((tam>MAX) || (tam<=0));
reversa.Cargar(Vec,tam);
reversa.Revertido(Vec,tam);
getch();
	
}

