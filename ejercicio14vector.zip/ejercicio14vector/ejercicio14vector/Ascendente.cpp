#include "StdAfx.h"
#include "Ascendente.h"
#include <iostream>
#define MAX 100

using namespace std;

Ascendente::Ascendente(void)
{ V[MAX]=0;
 tam=0;
}


Ascendente::~Ascendente(void)
{
}
void Ascendente::Cargar(float v[],float tam)
{ for(int i=0;i<tam;i++)
 {cout<<"V["<<i<<"]= ";
    cin>>v[i];
 }
}
void Ascendente::Ordenar(float v[],float tam)
{float aux;
 for(int i=0;i<tam-1;i++)
  {for(int k=i+1;k<tam;k++)
   {if(v[i]>v[k])
    {aux=v[k];
     v[k]=v[i];
	 v[i]=aux;
    }
   } 
  }
}
void Ascendente::Mostrar(float v[],float tam)
{cout<<"Vector ordenado"<<endl;
 for(int i=0;i<tam;i++)
 {cout<<"V["<<i<<"]= "<<v[i]<<endl;
 }
}
