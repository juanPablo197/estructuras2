#pragma once
#define MAX 100
class Ascendente
{private:
float V[MAX],tam;
public:
	Ascendente(void);
	~Ascendente(void);
	void Cargar(float v[],float tam);
	void Ordenar(float v[],float tam);
	void Mostrar(float v[],float tam);
};

