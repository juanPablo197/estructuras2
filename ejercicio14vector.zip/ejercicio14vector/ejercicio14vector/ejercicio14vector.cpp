// ejercicio14vector.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "Ascendente.h"
#include <iostream>
#include "conio.h"
#define MAX 100

using namespace std;

void main()
{float V[MAX],tam;
 Ascendente orden;
  do {
		cout<<"Ingrese el tamanio del vector: ";
		cin>>tam;
	} while ((tam>MAX) || (tam<=0));
  orden.Cargar(V,tam);
  orden.Ordenar(V,tam);
  orden.Mostrar(V,tam);
  getch();
}

