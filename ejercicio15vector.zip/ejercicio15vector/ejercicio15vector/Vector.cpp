#include "StdAfx.h"
#include "Vector.h"
#include <iostream>
#include "conio.h"
#define MAX 100
using namespace std;

Vector::Vector(void)
{	notas[MAX]=0;
	tam=0;
	registro[MAX]=0;
}


Vector::~Vector(void)
{
}
void Vector::cargar(double notas[],int registro[],int tam)
{for(int i=0;i<tam;i++)
 {do
  {cout<<"Registro del alumno "<<i+1<<" :"<<endl;
   cin>>registro[i];
  }while(registro[i]<1000000000 || registro[i]>10000000000);
  do
  {cout<<"Nota del alumno "<<i+1<<" :"<<endl;
   cin>>notas[i];
  }while(notas[i]<0 || notas[i]>100);
 }
cout<<"-----------registro--------------------Nota------------"<<endl;
  for(int k=0;k<tam;k++)
 {cout<<"          "<<registro[k]<<"                    "<<notas[k]<<endl;
 }

}
void Vector::ordenar (double notas[],int registro[],int tam)
{ int may1,may2,may3;
  int mayr1,mayr2,mayr3;
  may1=notas[0];
  may2=notas[0];
  may3=notas[0];
  mayr1=registro[0];
  mayr2=registro[0];
  mayr3=registro[0];
 for(int k=0;k<tam;k++)
 {if(notas[k]>may1)
  {may1=notas[k];
   mayr1=registro[k];
  }
  else
  {if(notas[k]>may2)
   {may2=notas[k];
    mayr2=registro[k];
   }
   else
   {if(notas[k]>may3)
    {may3=notas[k];
     mayr3=registro[k];
    }
   }
  }
 }
 cout<<"Las tres notas mas altas son:"<<endl;
  cout<<"-----------registro--------------------Nota------------"<<endl;
  cout<<"          "<<mayr1<<"                    "<<may1<<endl;
  cout<<"          "<<mayr2<<"                    "<<may2<<endl;
  cout<<"          "<<mayr3<<"                    "<<may3<<endl;
  getch();

}