#pragma once
#include <string>
#define MAX 100
class Vector
{private:
 double notas[MAX];
 int registro[MAX];
 int tam;
public:
	Vector(void);
	~Vector(void);
	void cargar(double notas[],int registro[],int tam);
	void ordenar (double notas[],int registro[],int tam);
};

