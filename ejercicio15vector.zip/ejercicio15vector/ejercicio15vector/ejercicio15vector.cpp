// ejercicio15vector.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
#include "Vector.h"
#include "conio.h"

#define MAX 100

using namespace std;

void main()
{double notas[MAX];
 int registro[MAX];
 int tam;
 Vector vector1;
 do {cout<<"Ingrese el la cantidad de alumnos : ";
	cin>>tam;
	} while ((tam>MAX) || (tam<=0));
 vector1.cargar(notas,registro,tam);
 vector1.ordenar(notas,registro,tam);
 getch();
}

