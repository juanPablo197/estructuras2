#include "StdAfx.h"
#include "Lista.h"
#include <iostream>
#include <iomanip>
#include "string.h"
#define MAX 100

using namespace std;

Lista::Lista(void)
{Nota[MAX]=0;
 lim=0;
 Alumnos[MAX][50]=0;
}


Lista::~Lista(void)
{
}
 void Lista::Cargar(int n[],char a[],int lim)
 {for (int i = 0; i < lim ;i++)
  {cout<<"\n Ingrese el nombre del alumno ["<<i+1<<" ]: ";
   fflush(stdin); 
   gets(Alumnos[i]);
   cout<<"\n Ingrese la nota del alumno ["<<i+1<<" ]: "; 
   cin>>n[i]; 
}
}

 void Lista::Mostrar(int n[],char a[],int lim)
 {cout<<"\n ---------------LISTA---------------";
  cout<<"\n ALUMNO                    NOTA";
  for (int i =0; i< lim; i++){
  cout<<"\n "<<Alumnos[i]<<"                       "<<n[i]<<endl;
  }
}

 void Lista::Ordenar(int n[],char a[],int lim)
 {float aux;
char auxt[30];
int r;
for (int i = 0; i < lim-1 ;i++) 
{for (int j = i+1; j < lim ;j++) 
 {r = strcmp (Alumnos[i],Alumnos[j]);
 if (r>0) { 
 aux = n[i];
 n[i] = n[j]; 
 n[j] = aux;
 strcpy(auxt,Alumnos[i]);
 strcpy(Alumnos[i],Alumnos[j]); 
 strcpy(Alumnos[j],auxt);
 }
 }
}
 cout<<"\n ----------Alumnos ordenados alfabeticamente----------";
  cout<<"\n ALUMNO                    NOTA";
 for (int i =0; i< lim; i++)
  {
  cout<<"\n"<<Alumnos[i]<<"                   "<<n[i]<<endl;
  }
 }
 void Lista::Mayor(int n[],char a[],int lim)
 {float notamayor;
  char mejoralumno[50];
  notamayor = n[0];
  strcpy(mejoralumno,Alumnos[0]);
  for (int i =0;i<lim;i++)
   {if (n[i]>notamayor)
     {notamayor = n[i];
      strcpy(mejoralumno,Alumnos[i]);
     }
}
cout<<"\n "<<mejoralumno<< " tiene la mejor nota que es "<<notamayor<<endl;
}
 void Lista::Promedio(int n[],int lim)
 {float P=0;
  for (int i =0;i<lim;i++)
   {P = P + n[i];
   }
    P = P/lim;
   cout<<"\n El promedio de notas del curso es de "<<P<<endl;
}

