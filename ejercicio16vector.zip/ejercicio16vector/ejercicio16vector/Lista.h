#pragma once
#define MAX 100
class Lista
{private:
int Nota[MAX],lim,opc;
char Alumnos[MAX][50];
public:
	Lista(void);
	~Lista(void);
 void Cargar(int n[],char a[],int lim);
 void Mostrar(int n[],char a[],int lim);
 void Ordenar(int n[],char a[],int lim);
 void Mayor(int n[],char a[],int lim);
 void Promedio(int n[],int lim);
};

