// ejercicio16vector.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "Lista.h"
#include <iostream>
#include "conio.h"
#include <iomanip>
#define MAX 100

using namespace std;

void main()
{int Nota[MAX],lim,opc;
 char Alumnos[MAX][50];
 Lista listita;
 do {
		cout<<"Ingrese la cantidad de alumnos ";
		cin>>lim;
	} while ((lim>MAX) || (lim<=0));
 do{cout<<"---------------------MENU----------------"<<endl;
    cout<<"1) Ingresar un alumno y su nota "<<endl;
    cout<<"2) Listar los alumnos"<<endl;
	cout<<"3) Ordenar alfab�ticamente"<<endl;
	cout<<"4) Sacar la mejor nota"<<endl;
	cout<<"5) Sacar el promedio de notas"<<endl;
	cout<<"6)SALIR"<<endl;
	cout<<"-----------------------------------------"<<endl;
	cin>>opc;
	switch(opc)
	{ case 1: 
	  listita.Cargar(Nota,Alumnos[50],lim);
	  break;
	case 2:
		listita.Mostrar(Nota,Alumnos[50],lim);
		break;
	case 3:
		listita.Ordenar(Nota,Alumnos[50],lim);
		break;
	case 4:
		listita.Mayor(Nota,Alumnos[50],lim);
		break;
	case 5:
		listita.Promedio(Nota,lim);
		break;
	case 6:
		cout<<"USTED HA SALIDO DEL PROGRAMA"<<endl;
		break;
	}
 }while(opc!=6);
 cout<<"ADIOS"<<endl;
 getch();
}

