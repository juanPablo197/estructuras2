#include "StdAfx.h"
#include "Valores.h"
#include <iostream>
#define MAX 100
using namespace std;

Valores::Valores(void)
{   tam=0;
	Vec[MAX]=0;
}


Valores::~Valores(void)
{
}

void Valores::cargar(int vec[],int tam)
{for(int i=0;i<tam;i++)
 {cout<<"V["<<i<<"]= ";
  cin>>vec[i]; 
 }
}
void Valores::mostrar(int vec[],int tam)
{int max;
 max=vec[0];
 for(int i=0;i<tam;i++)
 {if(vec[i]>max)
  {max=vec[i];
  }
 }
 cout<<"el mayor valor del vector es "<<max<<endl;
}