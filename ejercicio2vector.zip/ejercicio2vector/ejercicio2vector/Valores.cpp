#include "StdAfx.h"
#include "Valores.h"
#include <iostream>
#define MAX 100
using namespace std;

Valores::Valores(void)
{
	 tam=0;
	Vec[MAX]=0;
}


Valores::~Valores(void)
{
}
void Valores::cargar(int vec[],int tam)
{for(int i=0;i<tam;i++)
 {cout<<"V["<<i<<"]= ";
  cin>>vec[i]; 
 }
}
void Valores::mostrar(int vec[],int tam)
{int men;
 men=vec[0];
 for(int i=0;i<tam;i++)
 {if(vec[i]<men)
  {men=vec[i];
  }
 }
 cout<<"el menor valor del vector es "<<men<<endl;
}
