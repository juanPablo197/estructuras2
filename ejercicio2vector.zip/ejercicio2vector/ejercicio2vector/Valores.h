#pragma once
#define MAX 100
class Valores
{
private:
	int Vec[MAX],tam;
	
public:
	Valores(void);
	~Valores(void);
	void cargar(int vec[],int tam);
	void mostrar(int vec[],int tam);
};

