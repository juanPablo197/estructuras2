// ejercicio2vector.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "Valores.h"
#include <iostream>
#include "conio.h"
#define MAX 100

using namespace std;



void main()
{ int Vec[MAX], tam;
 Valores valor;
 do {
		cout<<"Ingrese el tamanio del vector : ";
		cin>>tam;
	} while ((tam>MAX) || (tam<=0));
 valor.cargar(Vec,tam);
 valor.mostrar(Vec,tam);
 getch();
	
}
