#include "StdAfx.h"
#include "Vector.h"
#include <iostream>
#define MAX 100
using namespace std;

Vector::Vector(void)
{ 
	notas[MAX]=0;
	tam=0;
}


Vector::~Vector(void)
{
}
void Vector::cargar(double notas[],int tam)
{for(int i=0;i<tam;i++)
 {do
   {cout<<"V["<<i<<"]= ";
    cin>>notas[i];
	if(notas[i]<0)
	{cout<<"\n NO PUEDE INGRESAR NOTA NEGATIVA"<<endl;
	 cout<<"Ingrese otra nota"<<endl;
	}
	else
	{if(notas[i]>100)
	 {cout<<"\n NO PUEDE INGRESAR NOTA MAYOR A 100 (NOTA MAXIMA)"<<endl;
	 cout<<"Ingrese otra nota"<<endl;
	 }
	}
   }while(notas[i]<0 || notas[i]>100);
 }
}
double Vector::promedio (double notas[],int tam)
{double suma=0;
 for(int i=0; i<tam;i++)
 {suma=suma+notas[i];
 }
 return suma/tam ;
}
