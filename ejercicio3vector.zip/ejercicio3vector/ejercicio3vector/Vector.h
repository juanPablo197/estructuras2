#pragma once
#define MAX 100
class Vector
{private:
 double notas[MAX];
 int tam;
 public:
	Vector(void);
	~Vector(void);
	void cargar(double notas[],int tam);
	double promedio (double notas[],int tam);
};

