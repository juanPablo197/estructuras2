#include "StdAfx.h"
#include "Vector.h"
#include <iostream>

#define MAX 10

using namespace std;
Vector::Vector(void)
{ V[MAX]=0;
  P[MAX]=0;
  tam=0;
}


Vector::~Vector(void)
{
}
void Vector::Cargar(int v[],int tam)
{for(int i=0;i<tam;i++)
 {cout<<"V["<<i<<"]= ";
  cin>>v[i]; 
 }
}
void Vector::Ordenar(int v[],int p[],int tam)
{
 for(int i=tam-1,k=0;k<tam;k++,i--)
 {p[k]=v[i];
 } 
 cout<<"VECTOR ORIGINAL"<<endl;
 for(int i=0;i<tam;i++)
 {cout<<"V["<<i<<"]= "<<v[i]<<endl; 
 }
  cout<<"VECTOR INVERSO"<<endl;
 for(int i=0;i<tam;i++)
 {cout<<"P["<<i<<"]= "<<p[i]<<endl;; 
 }
}
