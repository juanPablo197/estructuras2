#pragma once
#define MAX 10
class Vector
{private: 
 int V[MAX],P[MAX],tam;
public:
	Vector(void);
	~Vector(void);
	void Cargar(int v[],int tam);
	void Ordenar(int v[],int p[],int tam);
};

