// ejercicio4vector.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
#include "Vector.h"
#include "conio.h"

#define MAX 10

using namespace std;
void main()
{int V[MAX],P[MAX],tam;
 Vector vector1;
 do
 {cout<<"Ingrese el tamanio del vector:";
  cin>>tam;
 }while(tam<0 || tam>MAX);
 vector1.Cargar(V,tam);
 vector1.Ordenar(V,P,tam);
 getch();
}

