#include "StdAfx.h"
#include "Capicua.h"
#include <iostream>

#define MAX 10

using namespace std;

Capicua::Capicua(void)
{V[MAX]=0;
  P[MAX]=0;
  tam=0;
}


Capicua::~Capicua(void)
{
}
void Capicua::Cargar(int v[],int tam)
{for(int i=0;i<tam;i++)
 {cout<<"V["<<i<<"]= ";
  cin>>v[i]; 
 }
}
void Capicua::Ordenar(int v[],int p[],int tam)
{
 for(int i=tam-1,k=0;k<tam;k++,i--)
 {p[k]=v[i];
 } 
 cout<<"VECTOR ORIGINAL"<<endl;
 for(int i=0;i<tam;i++)
 {cout<<"V["<<i<<"]= "<<v[i]<<endl; 
 }
  cout<<"VECTOR INVERSO"<<endl;
 for(int i=0;i<tam;i++)
 {cout<<"P["<<i<<"]= "<<p[i]<<endl;; 
 }

 int aux=0;
 for(int k=0;k<tam;k++)
 {if(v[k]==p[k])
  {aux++;
  }
 } 
 if(aux==tam)
 {cout<<"El vector es CAPICUA"<<endl;
 }
 else
 {
  cout<<"El vector no es CAPICUA"<<endl;
 }

}


