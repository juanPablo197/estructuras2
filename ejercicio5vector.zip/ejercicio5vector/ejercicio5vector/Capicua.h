#pragma once
#define MAX 10
class Capicua
{private: 
 int V[MAX],P[MAX],tam;
public:
	Capicua(void);
	~Capicua(void);
	void Cargar(int v[],int tam);
	void Ordenar(int v[],int p[],int tam);
};

