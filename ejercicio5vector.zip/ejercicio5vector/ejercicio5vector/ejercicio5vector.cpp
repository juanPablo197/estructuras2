// ejercicio5vector.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "Capicua.h"
#include <iostream>
#include "conio.h"
#define MAX 10
using namespace std;

void main()
{int V[MAX],P[MAX],tam;
 Capicua vector;
 do
 {cout<<"Ingrese el tamanio del vector:";
  cin>>tam;
 }while(tam<0 || tam>MAX);
 vector.Cargar(V,tam);
 vector.Ordenar(V,P,tam);
 getch();
}

