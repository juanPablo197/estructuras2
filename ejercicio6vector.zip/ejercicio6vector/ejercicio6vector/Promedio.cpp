#include "StdAfx.h"
#include "Promedio.h"
#include <iostream>

#define MAX 10

using namespace std;

Promedio::Promedio(void)
{V[MAX]=0;
  tam=0;
}


Promedio::~Promedio(void)
{
}
void Promedio::Cargar(float v[],int tam)
{for(int i=0;i<tam;i++)
 {cout<<"V["<<i<<"]= ";
  cin>>v[i]; 
 }
}
void Promedio::Promedios(float v[],int tam)
{float sum,prom;
 for(int pos=0;pos<tam-2;pos++)
 {sum=v[pos]+v[pos+1]+v[pos+2];
  prom=sum/3;
  cout<<"El promedio de entre "<<v[pos]<<","<<v[pos+1]<<","<<v[pos+2]<<" es "<<prom<<endl;
 }

}
