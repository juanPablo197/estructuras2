#pragma once
#define MAX 10
class Promedio
{private: 
 float V[MAX];
 int tam;
public:
	Promedio(void);
	~Promedio(void);
	void Cargar(float v[],int tam);
	void Promedios(float v[],int tam);
};

