// ejercicio6vector.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "Promedio.h"
#include <iostream>
#include "conio.h"

#define MAX 10
using namespace std;

void main()
{float V[MAX];
 int tam;
 Promedio promedito;
 do {
		cout<<"Ingrese el tamanio del vector : ";
		cin>>tam;
	} while ((tam>MAX) || (tam<=0));
 promedito.Cargar(V,tam);
 promedito.Promedios(V,tam);
 getch();
}

