#include "StdAfx.h"
#include "Numero.h"


Numero::Numero(void)
{
}


Numero::~Numero(void)
{
}
void Numero::mostrar(string vector_numero[], int tam, int pos)
{	
 cout<<vector_numero[pos]<<endl;
}
