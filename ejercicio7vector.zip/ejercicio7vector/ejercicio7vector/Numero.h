#pragma once
#include <string>
#include <iostream>

#define MAX 20
using namespace std;

class Numero
{private: 

	string vector_numero[MAX];
	int tam, pos;
	
public:
	Numero(void);
	~Numero(void);
	void mostrar (string vector_numero[], int tam, int pos);
};

