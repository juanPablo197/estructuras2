// ejercicio7vector.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
#include <conio.h>
#include "Numero.h"
#define MAX 20

using namespace std; 

void main()
{int numero;
 string vector[MAX] = { "Uno","Dos","Tres","Cuatro","Cinco","Seis","Siete","Ocho","Nueve","Diez",
	"Once","Doce","Trece","Catorce","Quince","Dieciseis","Diecisiete","Dieciocho","Diecinueve","Veinte" };
	do
	{cout<<"Ingrese un numero para ser escrito literalmente: "<<endl;
	cin>> numero; 
	 if (numero>20)
	{cout<<"Ingrese un numero menor a 20"<<endl;
	}
	}
	while (numero>20);
	numero = numero-1;
	Numero numerito;
	numerito.mostrar(vector,MAX,numero);
	getch();
}

