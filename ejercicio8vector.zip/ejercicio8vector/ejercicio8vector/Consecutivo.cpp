#include "StdAfx.h"
#include "Consecutivo.h"
#include <iostream>
#define MAX 100

using namespace std;

Consecutivo::Consecutivo(void)
{Vec[MAX]=0;
 tam=0;
}


Consecutivo::~Consecutivo(void)
{
}
void Consecutivo::Cargar(int vec[],int tam)
{for(int i=0;i<tam;i++)
 {cout<<"V["<<i<<"]= ";
    cin>>vec[i];
 }
}

void Consecutivo::Diferencia(int vec[],int tam)
{int dif=0,may=0;
 for(int i=0;i<tam-1;i++)
 {dif=abs(vec[i]-vec[i+1]);
  cout<<"La diferencia entre "<<vec[i]<<" y "<<vec[i+1]<<" es "<<dif<<endl;
  if(dif>may)
  {may=dif;
  }
 }
 cout<<"La mayor diferencia entre numeros consecutivos del vector es "<<may<<endl;
 

}
