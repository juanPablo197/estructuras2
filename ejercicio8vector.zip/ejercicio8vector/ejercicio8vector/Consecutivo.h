#pragma once
#define MAX 100

class Consecutivo
{private:
int Vec[MAX],tam;
public:
	Consecutivo(void);
	~Consecutivo(void);
	void Cargar(int vec[],int tam);
	void Diferencia(int vec[],int tam);
};

