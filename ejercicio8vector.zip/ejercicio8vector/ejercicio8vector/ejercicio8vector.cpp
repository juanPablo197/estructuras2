// ejercicio8vector.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
#include "Consecutivo.h"
#include "conio.h"

#define MAX 100

using namespace std;

void main()
{int Vec[MAX],tam;
Consecutivo consec;
do {
		cout<<"Ingrese el tamanio del vector : ";
		cin>>tam;
	} while ((tam>MAX) || (tam<=0));
consec.Cargar(Vec,tam);
consec.Diferencia(Vec,tam);
getch();


}

