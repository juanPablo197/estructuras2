#include "StdAfx.h"
#include "Vectores.h"
#include <iostream>
#define MAX 100

using namespace std;

Vectores::Vectores(void)
{V[MAX]=0;
A[MAX]=0;
Z[MAX]=0;
n=0;
m=0;
c=0;
}


Vectores::~Vectores(void)
{
}
void Vectores::Cargar(int v[],int a[],int n,int m)
{cout<<"Llenando el vector 1 con "<<n<<" elementos..."<<endl;
 for(int i=0;i<n;i++)
 {cout<<"V["<<i<<"]= ";
    cin>>v[i];
 }
 cout<<"Llenando el vector 2 con "<<m<<" elementos..."<<endl;
 for(int i=0;i<m;i++)
 {cout<<"A["<<i<<"]= ";
    cin>>A[i];
 }
}
void Vectores::Concatenar(int v[],int a[],int z[],int n,int c)
{for(int i=0;i<c;i++)
 {if(i<n)
  {z[i]=v[i];
  }
  else
  {if(i>=n)
   {z[i]=A[i-n];
   }
  }
 }
}
void Vectores::Mostrar(int z[],int c)
{cout<<"\n mostrando vector concatenado"<<endl;
 for(int pos=0;pos<c;pos++)
 {cout<<"Z["<<pos<<"]= "<<z[pos]<<endl;
 }
}
